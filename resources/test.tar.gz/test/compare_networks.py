import sys
import datetime
import argparse
import csv

class Wegvak:
    def __init__(self, id):
        self.id = id

        self.hectoLetter = None
        self.roadNumber = None
        self.position = None
        self.doelGroep = None
        self.wisselBaan = None

class Baan:

    wegVakken = None

    def __init__(self, id):
        self.id = id
        self.wegVakken = {}

class Comparator:
    linkFile = None
    wegVakTableFile = None
    wegVakTablePrevYearFile = None

    POS_LINK_FILE_BAANNR_PREV_YEAR = 0
    POS_LINK_FILE_BAANNR = 1

    POS_WEGVAK_BAAN_NO = 4
    POS_WEGVAK_WEGVAK_VOLG_NR = 5
    POS_WEGVAK_WEGVAK_POSITIE = 6
    POS_WEGVAK_WEGNUMMER = 10
    POS_WEGVAK_HECTO_LETTER = 13
    POS_WEGVAK_DOELGROEP = 19
    POS_WEGVAK_WISSELBAAN = 20

    POS_WEGVAK_OLD_FORMAT_BAAN_NO = 3
    POS_WEGVAK_OLD_FORMAT_WEGVAK_VOLG_NR = 4
    POS_WEGVAK_OLD_FORMAT_WEGVAK_POSITIE = 5
    POS_WEGVAK_OLD_FORMAT_WEGNUMMER = 9
    POS_WEGVAK_OLD_FORMAT_HECTO_LETTER = 12

    baan2baanPrevYear = {}
    banen = {}
    banenPrevYear = {}

    wegVakHeader = None

    format2016 = False

    def __init__(self, linkFile, wegVakTableFile, wegVakTablePrevYearFile):
        self.linkFile = linkFile
        self.wegVakTableFile = wegVakTableFile
        self.wegVakTablePrevYearFile = wegVakTablePrevYearFile

    def set2016Format(self):
        self.format2016 = True

    def mergeLines(self, lines):
        if len(lines) == 1:
            return lines[0]

        line = ""

        for l in lines:
            line = line + l

        return line

    def readLinkFile(self):
        with open(self.linkFile) as tsv:

            reader = csv.reader(tsv)
            next(reader)

            for lines in reader:
                line = self.mergeLines(lines)

                values = [x for x in line.split('\t')]

                baanNoPrevYear = values[self.POS_LINK_FILE_BAANNR_PREV_YEAR]
                baanNo = values[self.POS_LINK_FILE_BAANNR]

                if baanNo != '' and baanNoPrevYear != '':
                    self.baan2baanPrevYear[int(baanNo)] = int(baanNoPrevYear)

    def readWegVakTable(self, wegVakTableFile, banen):
        with open(wegVakTableFile) as tsv:
            for lines in csv.reader(tsv):
                line = self.mergeLines(lines)

                if line[0] == "#":
                    continue

                values = [x for x in line.split('\t')]

                if self.wegVakHeader == None:
                    self.wegVakHeader = values
                    continue

                baanNo = values[self.POS_WEGVAK_BAAN_NO]
                wegVakVolgNo = values[self.POS_WEGVAK_WEGVAK_VOLG_NR]

                if baanNo == "" or wegVakVolgNo == "":
                    continue

                baanNo = int(baanNo)
                wegVakVolgNo = int(wegVakVolgNo)

                if baanNo not in banen:
                    baan = Baan(baanNo)
                    banen[baanNo] = baan
                else:
                    baan = banen[baanNo]

                if wegVakVolgNo not in baan.wegVakken:
                    wegVak = Wegvak(wegVakVolgNo)
                    wegVak.hectoLetter = values[self.POS_WEGVAK_HECTO_LETTER]
                    wegVak.position = values[self.POS_WEGVAK_WEGVAK_POSITIE]
                    wegVak.roadNumber = values[self.POS_WEGVAK_WEGNUMMER]
                    wegVak.doelGroep = values[self.POS_WEGVAK_DOELGROEP]
                    wegVak.wisselBaan = values[self.POS_WEGVAK_WISSELBAAN]

                    baan.wegVakken[wegVakVolgNo] = wegVak
                else:
                    print("Baan %d heeft al een wegvak met wegvak-volgnr %d" % (baan.id, wegVakVolgNo))

    def readWegVakTableOldFormat(self, wegVakTableFile, banen):

        parsedHeader = False

        with open(wegVakTableFile) as tsv:
            for lines in csv.reader(tsv):
                line = self.mergeLines(lines)

                if line[0] == "#":
                    continue

                values = [x for x in line.split('\t')]

                if not parsedHeader:
                    parsedHeader = True
                    continue

                baanNo = values[self.POS_WEGVAK_OLD_FORMAT_BAAN_NO]
                wegVakVolgNo = values[self.POS_WEGVAK_OLD_FORMAT_WEGVAK_VOLG_NR]

                if baanNo == "" or wegVakVolgNo == "":
                    continue

                baanNo = int(baanNo)
                wegVakVolgNo = int(wegVakVolgNo)

                if baanNo not in banen:
                    baan = Baan(baanNo)
                    banen[baanNo] = baan
                else:
                    baan = banen[baanNo]

                if wegVakVolgNo not in baan.wegVakken:
                    wegVak = Wegvak(wegVakVolgNo)
                    wegVak.hectoLetter = values[self.POS_WEGVAK_OLD_FORMAT_HECTO_LETTER]
                    wegVak.roadNumber = values[self.POS_WEGVAK_OLD_FORMAT_WEGNUMMER]
                    wegVak.position = values[self.POS_WEGVAK_OLD_FORMAT_WEGVAK_POSITIE]
                    baan.wegVakken[wegVakVolgNo] = wegVak
                else:
                    print("Baan %d heeft al een wegvak met wegvak-volgnr %d" % (baan.id, wegVakVolgNo))

    def compareField(self, baanNo, baanNoPrevYear, wegVakVolgNo, fieldNo, f1, f2):
        if f1 != f2:
            print("BaanNo: %s, baanNoPrevYear: %s, wegvak-volgnr: %d, field: %s, diff: %s -> %s" % (baanNo, baanNoPrevYear, wegVakVolgNo, self.wegVakHeader[fieldNo], f1, f2))

    def compare(self):
        self.readLinkFile()
        self.readWegVakTable(self.wegVakTableFile, self.banen)

        if self.format2016:
            self.readWegVakTableOldFormat(self.wegVakTablePrevYearFile, self.banenPrevYear)
        else:
            self.readWegVakTable(self.wegVakTablePrevYearFile, self.banenPrevYear)

        for id in self.banen:
            if id in self.baan2baanPrevYear:
                if self.baan2baanPrevYear[id] in self.banenPrevYear:
                    self.compareBaan(self.banen[id], self.banenPrevYear[self.baan2baanPrevYear[id]])

    def compareBaan(self, baan, baanPrevYear):
        for idx in range(0, len(baan.wegVakken)):
            if idx in baan.wegVakken and idx in baanPrevYear.wegVakken:
                self.compareField(baan.id, baanPrevYear.id, idx, self.POS_WEGVAK_WEGNUMMER, baan.wegVakken[idx].roadNumber, baanPrevYear.wegVakken[idx].roadNumber)
                self.compareField(baan.id, baanPrevYear.id, idx, self.POS_WEGVAK_HECTO_LETTER, baan.wegVakken[idx].hectoLetter, baanPrevYear.wegVakken[idx].hectoLetter)
                self.compareField(baan.id, baanPrevYear.id, idx, self.POS_WEGVAK_WEGVAK_POSITIE, baan.wegVakken[idx].position, baanPrevYear.wegVakken[idx].position)

if __name__ == '__main__':
    sys.stdout.write("Aangeroepen op %s -> " % (datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')))

    for arg in sys.argv[0:]:
        sys.stdout.write("%s " % arg)

    print("")

    parser = argparse.ArgumentParser()

    parser.add_argument('-l', help='-l link-tabel', required=True)
    parser.add_argument('-w', help='-w weg-vak-tabel', required=True)
    parser.add_argument('-w-prev-year', help='-w weg-vak-tabel-previous-year', required=True)
    parser.add_argument('-y', help='-y', action='store_true')

    arguments = vars(parser.parse_args())

    comparator = Comparator(arguments['l'], arguments['w'], arguments['w_prev_year'])

    if arguments['y']:
        comparator.set2016Format()

    comparator.compare()

