#!/usr/bin/python2

import compileall

compileall.compile_dir(".", force=1)

